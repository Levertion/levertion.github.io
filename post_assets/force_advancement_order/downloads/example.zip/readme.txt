This is an example advancement to show how to make one advancement require another to be collected beforehand
This was made by https://twitter.com/LevertionMC for https://levertion.github.io/advancements/force-advancement-order
This is in the public domain